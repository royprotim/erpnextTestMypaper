GitDB is a pure-Python git object database


